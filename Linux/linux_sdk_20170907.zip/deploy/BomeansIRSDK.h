﻿

#ifndef _BOMEANS_IR_SDK_H_
#define _BOMEANS_IR_SDK_H_

#include "BomeansConst.h"
#include "IRKit.h"
#include "Web.h"


#define USING_BOMEANS using namespace BOMEANS_LIB_NAME;



#endif   // _BOMEANS_IR_SDK_H_